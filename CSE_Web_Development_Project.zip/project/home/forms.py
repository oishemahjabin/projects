from django import forms
from home.models import Tenant

class TenantForm(forms.ModelForm):
    class Meta:
        model=Tenant
        fields="_all_"
