from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("",views.index,name='home'),
    path("about",views.about,name='about'),
    path("services",views.services,name='services'),
    path("feedback",views.feedback,name='feedback'),
    path("rooms",views.rooms,name='rooms'),
    path("reserve",views.reserve,name='reserve'),
    path("home",views.index,name='home'),
    path("roomimage",views.roomimage,name='roomimage'),
    path('<int:id>/',views.image,name='image'),
    path("bills",views.bills,name='bills'),
    path("bills1",views.bills1,name='bills1'),
    path("pay",views.pay,name='pay'),
    path("pay2",views.pay2,name='pay2'),
    path("pay1",views.pay1,name='pay1'),
    path("depart",views.depart,name='depart'),
    path("contact",views.contact,name='contact'),
]