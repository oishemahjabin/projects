#from django.db import connections
from django.db import models

# Create your models here.
#class RoomsModel(models.Model):

class Rooms(models.Model):
    roomid=models.CharField(max_length=10)
    Room_no=models.IntegerField()
    Price=models.CharField(max_length=10)
    Category=models.CharField(max_length=255)
    #def __str__(self):
        #return self.ID

class Reserve(models.Model):
    roomno=models.CharField(max_length=100)
    fname  =models.CharField(max_length=122)    
    lname  =models.CharField(max_length=122)
    age    =models.IntegerField()
    members=models.IntegerField()
    email  =models.CharField(max_length=122)
    occu   =models.CharField(max_length=122)
    nid=models.IntegerField()
    contact=models.CharField(max_length=122)
    address  =models.CharField(max_length=122)
    
    def __str__(self):
        return self.roomno
    

class Post(models.Model):
    #ID=models.IntegerField(primary_key=True)
    title=models.CharField(max_length=255)
    description=models.TextField()
    image=models.ImageField(blank=True)
         
    def __str__(self):
        return self.title
    
       
class PostImage(models.Model):
   # ID=models.IntegerField(primary_key=True)
    post=models.ForeignKey(Post,default=None,on_delete=models.CASCADE)

    image=models.ImageField(upload_to="images/")    
    def __str__(self):
        return self.post.title

class Bills(models.Model):
    room_no=models.ForeignKey(Reserve,default=None,on_delete=models.CASCADE)
    house_rent=models.CharField(max_length=10)
    electricity=models.CharField(max_length=10)
    water=models.CharField(max_length=10)
    gas=models.CharField(max_length=10)
    month=models.CharField(max_length=100,default="January")
    def __str__(self):
        return self.room_no.roomno
    
        
class Feedback(models.Model):
    roomno=models.CharField(max_length=100)
    fname  =models.CharField(max_length=122)    
    lname  =models.CharField(max_length=122)
    email  =models.CharField(max_length=122)
    contact=models.CharField(max_length=122)
    desc  =models.TextField(max_length=300)
    
    def __str__(self):
        return self.roomno

class Depart(models.Model):
    roomno=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)

    def __str__(self):
        return self.roomno
