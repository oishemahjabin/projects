from django.contrib import admin
from home.models import Rooms
from home.models import Reserve
from home.models import Post
from home.models import PostImage
from home.models import Bills
from home.models import Feedback
from home.models import Depart


# Register your models here.
admin.site.register(Rooms)
admin.site.register(Reserve)
admin.site.register(Post)
admin.site.register(PostImage)
admin.site.register(Bills)
admin.site.register(Feedback)
admin.site.register(Depart)