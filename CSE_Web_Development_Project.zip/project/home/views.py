from django.shortcuts import render,HttpResponse,redirect,get_object_or_404
from home.models import Rooms
from home.models import Reserve
from home.models import Post
from home.models import PostImage
from home.models import Bills
from home.models import Feedback
from home.models import Depart

# Create your views here.

def index(request):
    return render(request,'index.html')
    
def about(request):
    return render(request,'about.html')
    

def services(request):
    return render(request,'services.html')
         
def feedback(request):

    
    
    #return render(request,'feedback.html')
    if request.method =="POST":

       
        roomno=request.POST.get('roomno')    
        fname=request.POST.get('fname')
        lname=request.POST.get('lname')   
        email=request.POST.get('email')
        contact=request.POST.get('contact')
        desc=request.POST.get('desc') 
        feedback=Feedback(roomno=roomno,fname=fname,lname=lname,email=email,contact=contact,desc=desc)
        feedback.save()
    roomno=request.POST.get('roomno')
    display=Reserve.objects.filter(roomno=roomno)    
    return render(request,'feedback.html',{'data':display})
   # return render(request,'feedback.html')
   
def rooms(request):
    
       Room_no=request.POST.get('Room_no')
       display=Rooms.objects.filter(Room_no=Room_no) 
       return render(request,'rooms.html',{'data':display})
    
def reserve(request):
    roomno={}
    context={}
    if request.method =="POST":
        fname=request.POST.get('fname')
        lname=request.POST.get('lname')   
        age=request.POST.get('age')   
        members=request.POST.get('members')
        email  =request.POST.get('email')
        occu   =request.POST.get('occu')
        nid=request.POST.get('nid')
        contact=request.POST.get('contact')
        address =request.POST.get('address')
        roomno  =request.POST.get('roomno')  
        reserve=Reserve(fname=fname,lname=lname,age=age,members=members,email=email,occu=occu,nid=nid,contact=contact,address=address,roomno=roomno)
        reserve.save()
    ob=Rooms.objects.filter(roomid=roomno)
    
    if len(ob)>0:
        display=Rooms.objects.get(roomid=roomno)
        
        display.Category="Booked" 
        display.save(update_fields=["Category"])
        context["data"]=display    
    return render(request,'reserve.html',context)    

def roomimage(request):
    
       title=request.POST.get('title')
       
       display=Post.objects.filter(title=title)
      
       return render(request,'roomimage.html',{'posts':display})
     

def image(request, id):

    post=get_object_or_404(Post,id=id)
    photos=PostImage.objects.filter(post=post)
    return render(request,'image.html',{'post':post,'photos':photos})
   

def bills(request):
    return render(request,'bills.html')  
    
def bills1(request):
    context={}
    room_no=request.POST.get('room_no')
    check=Reserve.objects.filter(roomno=room_no)
    if len(check)>0:
        res=Reserve.objects.get(roomno=room_no)
        display=Bills.objects.filter(room_no=res)
        context["data"]=display
    return render(request,'bills1.html',context)


def pay(request):
    dis={}
    room_no={}
    #if request.method =="POST":         
    room_no=request.POST.get('room_no')
    name=request.POST.get('name')
    check=Reserve.objects.filter(roomno=room_no)
    if len(check)>0:
        res=Reserve.objects.get(roomno=room_no)
        dis=Bills.objects.filter(room_no=res)
    display=Reserve.objects.filter(roomno=room_no)
    
    return render(request,'pay.html',{'data':display,'dat':dis}) 

def pay2(request):
    return render(request,'pay2.html') 

def pay1(request):
    return render(request,'pay1.html')    
def depart(request):
    roomno={}
    context={}
    if request.method =="POST":         
        roomno=request.POST.get('roomno')
        name=request.POST.get('name')
        email=request.POST.get('email')
        depart=Depart(roomno=roomno,name=name,email=email)
        depart.save()
    #roomno={}
    obj=Reserve.objects.filter(roomno=roomno)
    if len(obj)>0:
        dis=Reserve.objects.get(roomno=roomno)
        dis.delete()
    ob=Rooms.objects.filter(roomid=roomno)
    
    if len(ob)>0:
        display=Rooms.objects.get(roomid=roomno)
        
        display.Category="Available" 
        display.save(update_fields=["Category"])
        context["data"]=display
    return render(request,'depart.html',context)
    
def contact(request):
    return render(request,'contact.html')     